<?php declare(strict_types=1);

namespace Nuwave\Lighthouse\Support\Contracts;

/**
 * If this directive is defined on an argument definition that is
 * a list, it applies to each item within the list.
 */
interface ArgDirective extends Directive {}
