<?php declare(strict_types=1);

namespace Nuwave\Lighthouse\Scout;

class ScoutException extends \Exception {}
