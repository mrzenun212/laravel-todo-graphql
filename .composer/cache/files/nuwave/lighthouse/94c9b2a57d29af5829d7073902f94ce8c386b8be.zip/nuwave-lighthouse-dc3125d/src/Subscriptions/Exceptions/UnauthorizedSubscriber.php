<?php declare(strict_types=1);

namespace Nuwave\Lighthouse\Subscriptions\Exceptions;

use GraphQL\Error\Error;

class UnauthorizedSubscriber extends Error {}
