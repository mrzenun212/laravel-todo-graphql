<?php declare(strict_types=1);

namespace GraphQL\Type\Definition;

/*
GraphQLScalarType |
GraphQLObjectType |
GraphQLInterfaceType |
GraphQLUnionType |
GraphQLEnumType |
GraphQLList |
GraphQLNonNull;
*/

interface OutputType {}
